package com.example.proxsensor.Model;

import java.util.ArrayList;

public class Month {

    private String value;
    private ArrayList<Date> dates;

    public Month (String value) {
        this.value = value;
        dates = new ArrayList<>();
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void addDate(Date date) {
        this.dates.add(date);
    }

    public Date getDate(int index) {
        return this.dates.get(index);
    }

    public Date getDate(String value) {
        for (Date date : this.dates) {
            if (date.getValue().equals(value))
                return date;
        }
        return null;
    }

    public int indexOfDate(String value) {
        for (int i=0; i<this.dates.size(); i++) {
            if (this.dates.get(i).getValue().equals(value))
                return i;
        }
        return -1;
    }

    @Override
    public String toString () {
        StringBuilder string = new StringBuilder("\t" + this.value + ":\n");
        for (Date date : this.dates)
            string.append("\t\t\t").append(dates.toString()).append("\n");

        return string.toString();
    }

}
