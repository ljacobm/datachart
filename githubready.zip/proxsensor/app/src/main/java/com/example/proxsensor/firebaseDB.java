package com.example.proxsensor;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;


import com.example.proxsensor.Model.Color;
import com.example.proxsensor.Model.Date;
import com.example.proxsensor.Model.Month;
import com.example.proxsensor.Model.User;
import com.example.proxsensor.Model.Year;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

class firebaseDB {

    private DatabaseReference mDatabase;
    private ArrayList<User> users;
    private ChildEventListener listener;



        firebaseDB() {
        users = new ArrayList<>();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        listener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                User user = new User(dataSnapshot.getKey());

                for (DataSnapshot year : dataSnapshot.getChildren()) {
                    Year yy = new Year(year.getKey());
                    for (DataSnapshot month : year.getChildren()) {
                        Month mm = new Month(month.getKey());
                        for (DataSnapshot date : month.getChildren()) {
                            Date dd = new Date(date.getKey());
                            for (DataSnapshot color : date.getChildren()) {
                                Color c = new Color(color.getKey());
                                int num = 0;
                                for (DataSnapshot count : color.getChildren()) {
                                    String[] holder = String.valueOf(count.getValue()).split(":");
                                    num += Integer.parseInt(holder[1].trim());
                                }
                                c.setCount(num);
                                dd.addColor(c);
                            }
                            mm.addDate(dd);
                        }
                        yy.addMonth(mm);
                    }
                    user.addYear(yy);
                }
                users.add(user);
                Log.i("User ", user.toString());
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };

        attachListener();
    }


        @Override
    public String toString() {
        StringBuilder string = new StringBuilder();
        for (User user : this.users)
            string.append(user.toString()).append("\n");

        return string.toString();
    }

    public void detachListener() {
        mDatabase.child("users").removeEventListener(listener);
    }

    private void attachListener() {
        mDatabase.child("users").addChildEventListener(listener);
    }

}
