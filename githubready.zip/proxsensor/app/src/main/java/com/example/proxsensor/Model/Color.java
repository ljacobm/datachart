package com.example.proxsensor.Model;

import java.util.ArrayList;

public class Color {

    private String value;
    private int counts;

    public Color (String value) {
        this.value = value;
        counts = 0;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setCount(int i) {
        this.counts = i;
    }

    public int getCount(int index) {
        return this.counts;
    }

    @Override
    public String toString () {
        return "\t" + this.value + ":\t" + this.counts;
    }
}
