package com.example.proxsensor.Model;

import java.util.ArrayList;

public class User {

    private String ID;
    private ArrayList<Year> years;

    public User (String ID) {
        this.ID = ID;
        years = new ArrayList<>();
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void addYear(Year year) {
        this.years.add(year);
    }

    public Year getYear(int index) {
        return this.years.get(index);
    }

    public int indexOf(Year year) {
        return this.years.indexOf(year);
    }

    @Override
    public String toString () {
        StringBuilder string = new StringBuilder(this.ID + "\n");
        for (Year year : this.years)
            string.append("\t").append(year.toString()).append("\n");

        return string.toString();
    }

}
