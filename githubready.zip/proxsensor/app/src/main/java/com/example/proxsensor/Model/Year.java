package com.example.proxsensor.Model;

import java.util.ArrayList;

public class Year {

    private String value;
    private ArrayList<Month> months;

    public Year(String value) {
        this.value = value;
        months = new ArrayList<>();
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void addMonth(Month month) {
        this.months.add(month);
    }

    public Month getMonth(int index) {
        return this.months.get(index);
    }

    public int indexOf(Month month) {
        return this.months.indexOf(month);
    }

    public int indexOfMonth(String value) {
        for (int i=0; i<this.months.size(); i++) {
            if (this.months.get(i).getValue().equals(value))
                return i;
        }
        return -1;
    }

    @Override
    public String toString () {
        StringBuilder string = new StringBuilder("\t" + this.value + ":\n");
        for (Month month : this.months)
            string.append("\t\t").append(month.toString()).append("\n");

        return string.toString();
    }

}
