package com.example.proxsensor.Model;

import java.util.ArrayList;

public class Date {

    private String value;
    private ArrayList<Color> colors;

    public Date (String value) {
        this.value = value;
        colors = new ArrayList<>();
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void addColor(Color color) {
        this.colors.add(color);
    }

    public Color getColor(int index) {
        return this.colors.get(index);
    }

    public Color getColor(String value) {
        for (Color color : this.colors) {
            if (color.getValue().equals(value))
                return color;
        }
        return null;
    }

    public int indexOfColor(String value) {
        for (int i=0; i<this.colors.size(); i++) {
            if (this.colors.get(i).getValue().equals(value))
                return i;
        }
        return -1;
    }

    @Override
    public String toString () {
        StringBuilder string = new StringBuilder("\t" + this.value + ":\n");
        for (Color color : this.colors)
            string.append("\t\t\t\t").append(color.toString()).append("\n");

        return string.toString();
    }
}
